617019_NVIDIA_HQ_bldg.pgm: courtesy of NVIDIA
