nvprof ./pgi_laplacian 128 128 128 20000
